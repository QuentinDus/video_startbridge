import {Audio, Img, staticFile, useCurrentFrame, interpolate} from 'remotion';
import {AbsoluteFill, Sequence, spring, useVideoConfig} from 'remotion';
import React from 'react';

// Helpers ----------
const FadeText: React.FC<{text: string; delay: number; exit?: number}> = ({
  text,
  delay,
  exit,
}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();

  const inOpacity = spring({
    fps,
    frame: frame - delay,
    from: 0,
    to: 1,
    config: {damping: 200},
  });
  const outOpacity =
    exit !== undefined
      ? interpolate(frame, [exit, exit + fps / 5], [1, 0], {extrapolateRight: 'clamp'})
      : 1;

  return (
    <AbsoluteFill
      style={{
        justifyContent: 'center',
        alignItems: 'center',
        fontFamily: 'Inter, sans-serif',
        fontSize: 80,
        fontWeight: 700,
        color: 'white',
        padding: '0 80px',
        textAlign: 'center',
        opacity: inOpacity * outOpacity,
      }}
    >
      {text}
    </AbsoluteFill>
  );
};

// Main composition ---
export const StartBridgeAd: React.FC = () => {
  return (
    <AbsoluteFill style={{backgroundColor: '#111'}}>
      {/* 0-4 s : intro */}
      <Sequence from={0} durationInFrames={120}>
        <FadeText text="J'ai une idée." delay={0} exit={100} />
      </Sequence>

      {/* 4-8 s : le problème */}
      <Sequence from={120} durationInFrames={120}>
        <FadeText
          text="Pas ingénieur. Pas designer. Juste un cerveau en ébullition."
          delay={0}
          exit={100}
        />
      </Sequence>

      {/* 8-12 s : question qui tue */}
      <Sequence from={240} durationInFrames={120}>
        <FadeText text="« OK… tu commences par quoi ? »" delay={0} exit={100} />
      </Sequence>

      {/* 12-16 s : glitch → écran noir */}
      <Sequence from={360} durationInFrames={30}>
        <AbsoluteFill style={{backgroundColor: 'black'}} />
      </Sequence>

      {/* 16-28 s : Start Bridge en action (capture d’écran + zoom) */}
      <Sequence from={390} durationInFrames={360}>
        <Img
          src={staticFile('startbridge-ui.png')}
          style={{
            width: '120%',
            height: '120%',
            objectFit: 'cover',
            transform: `scale(1.1)`,
          }}
        />
      </Sequence>

      {/* 18-20 s : voice-over sync */}
      <Sequence from={450} durationInFrames={60}>
        <FadeText
          text="Start Bridge simplifie : idée → projet concret."
          delay={0}
        />
      </Sequence>

      {/* 28-32 s : preuves sociales */}
      <Sequence from={750} durationInFrames={120}>
        <FadeText
          text="Ingénieur·es, bricoleur·ses, rêveur·ses : ça avance."
          delay={0}
          exit={100}
        />
      </Sequence>

      {/* 32-36 s : plan d'action */}
      <Sequence from={870} durationInFrames={120}>
        <FadeText
          text="Roadmap, maquettes, réseau. Et je ne suis plus seul."
          delay={0}
          exit={100}
        />
      </Sequence>

      {/* 36-40 s : CTA */}
      <Sequence from={990} durationInFrames={120}>
        <FadeText
          text="Start Bridge – Lance ton idée aujourd'hui."
          delay={0}
        />
      </Sequence>

      {/* Audio bed en continu */}
      <Audio
        src={staticFile('bg-music.mp3')}
        startFrom={0}
        endAt={1200}
        volume={0.7}
      />
    </AbsoluteFill>
  );
};
