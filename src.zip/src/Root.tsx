import "./index.css";
import { Composition } from "remotion";
import { HelloWorld, myCompSchema } from "./HelloWorld";
import { Logo, myCompSchema2 } from "./HelloWorld/Logo";

// Each <Composition> is an entry in the sidebar!


registerRoot(() => (
  <>
    <Composition
      id="StartBridgeAd"
      component={StartBridgeAd}
      durationInFrames={1200}   // 40 s à 30 fps
      fps={30}
      width={1080}
      height={1920}             // format vertical reels/tiktok
    />
  </>
));